//
//  FlickrSearchResults.swift
//  HSBCTask
//
//  Created by M A Hossan on 01/03/2022.
//

import UIKit

struct FlickrSearchResults: Codable {
    let stat: String?
    let photos: Photos?
    
}

