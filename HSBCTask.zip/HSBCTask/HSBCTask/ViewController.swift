//
//  ViewController.swift
//  HSBCTask
//
//  Created by M A Hossan on 01/03/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

